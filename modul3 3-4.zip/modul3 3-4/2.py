def is_root(a: int, b: int, c: int, x: int) -> bool:
   return(a * x * x + b * x + c == 0)


a, b, c = 1, 0, -4
for x in range(-3, 3 + 1):
    verdict = "не корень"
    if is_root(a, b, c, x):
        verdict = "корень"
    print(x, verdict)