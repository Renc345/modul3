def add_two(number1: int, number2: int) -> int:
    return (number1 + number2)


print(add_two(5, 2))