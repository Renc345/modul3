def nok(num_1: int, num_2: int) -> int:
    round(num_1 * num_2 / nod(num_1, num_2))


def nod(a, b):
    while a != b:
        if a > b:
            a -= b
        else:
            b -= a
    return a


a = 25
b = 15
print(nod(a, b), nok(a, b))