def greeting_name(name: str) -> None:
    print(f'Привет, {name}!')


arg_name = "Иван"
greeting_name(arg_name)
