def blank_line(s_number: int) -> None:
    print('*' * s_number)


output_line = "1 2 3"
blank_line(len(output_line))
print(output_line)
blank_line(len(output_line))