def blank_line() -> None:
    print('*' * 10)

blank_line()
print(1, 2, 3, 4, 56)
blank_line()
