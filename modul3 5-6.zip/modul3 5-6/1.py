def odd_numbers(limit: int) -> None:
    for i in range(1, limit):
        if i % 2 != 0:
            print(i, end=' ')


odd_numbers(6)
