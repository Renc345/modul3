def print_triangle(lines_number: int) -> None:


for i in range(2, 5):
    print_triangle(i)
    print()